# GeoJSON of Saudi Arabia Regions
A script that builds a GeoJSON of Saudi Arabia goveranates with an demostration. 
